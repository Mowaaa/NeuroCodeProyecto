#!/bin/bash

LOG="/var/log/cuentas.log"
ERR_LOG="/var/log/cuentas_error.log"

log_info() {
	echo "[INFO] $(date '+%F %T') - $1" | sudo tee -a "$LOG" > /dev/null
}

log_error() {
	echo "[ERROR] $(date '+%F %T') - $1" | sudo tee -a "$ERR_LOG" > /dev/null
}

#Verifica si el archivo existe y en caso de que no lo haga lo crea, cambia los permisos y propietario al usaruio acutal
if [ ! -f "$LOG" ] || [ ! -f "$ERR_LOG" ]; then
	sudo touch "$LOG" "$ERR_LOG"
	sudo chmod 660 "$LOG" "$ERR_LOG"
	sudo chown "$(whoami):$(whoami)" "$LOG" "$ERR_LOG"
	echo "Archivos de log '$LOG' y de errores '$ERR_LOG' creados y permisos configurados."
else
    log_error "Los archivos logs ya existen"
fi

#INICIO DE LAS CONFIGURACIONES INICIALES AUTOMATICAS 

#Crea los grupos automaticamente en caso de que no existan
for grupo in superadmin dbadmin webadmin useradmin moderadores; do
  if ! getent group "$grupo" > /dev/null; then
    if sudo groupadd "$grupo"; then
      log_info "Grupo '$grupo' creado automáticamente"
    else
      log_error "Error al crear grupo '$grupo'"
    fi
  fi
done

#Se crea automaticamente los permisos sudoers 
SUDOERS_BACKUP="/etc/sudoers.bak_roles"       # Ruta de respaldo del archivo sudoers original
SUDOERS_TEMP="/tmp/sudoers_roles.tmp"         # Ruta temporal para escribir las nuevas reglas
#Verifica si ya existe el respaldo. Si no existe, aplica la configuración
if [ ! -f "$SUDOERS_BACKUP" ]; then
    echo "Aplicando configuraciones iniciales en sudoers para los roles"
    if sudo cp /etc/sudoers "$SUDOERS_BACKUP"; then
      log_info "Respaldo de sudoers creado en $SUDOERS_BACKUP"
    else
      log_error "Fallo al crear respaldo de sudoers"
    fi

    cat <<CONFIG | sudo tee "$SUDOERS_TEMP" > /dev/null

#Reglas personalizadas por rol 

# Grupo superadmin: tiene acceso total al sistema
%superadmin ALL=(ALL) ALL
# Grupo dbadmin: puede ejecutar comandos específicos relacionados con bases de datos sin ingresar contraseña
%dbadmin ALL=(ALL) NOPASSWD: /usr/bin/mysql, /usr/bin/mysqldump, /bin/systemctl restart mysql
# Grupo webadmin: puede reiniciar servicios web sin contraseña
%webadmin ALL=(ALL) NOPASSWD: /bin/systemctl restart apache2, /bin/systemctl restart php-fpm
# Grupo useradmin: puede gestionar usuarios y grupos sin contraseña
%useradmin ALL=(ALL) NOPASSWD: /usr/sbin/useradd, /usr/sbin/usermod, /usr/bin/passwd, /usr/sbin/groupadd, /usr/sbin/groupmod, /usr/sbin/groupdel
# Grupo moderadores: no se le asignan permisos sudo

#Fin de reglas personalizadas 

CONFIG

    if sudo bash -c "cat $SUDOERS_TEMP >> /etc/sudoers"; then
      log_info "Configuración de sudoers completada"
    else
      log_error "Error al aplicar configuración a sudoers"
    fi
fi

#Configuracion de bloqueos tras 3 intentos faillidos con SSH
SSHD_CONFIG="/etc/ssh/sshd_config"
BACKUP_SSHD="/etc/ssh/sshd_config.bak_roles"

if [ ! -f "$BACKUP_SSHD" ]; then
  if sudo cp "$SSHD_CONFIG" "$BACKUP_SSHD"; then
    log_info "Copia de seguridad de sshd_config creada"
  else
    log_error "Error al crear copia de sshd_config"
  fi
fi

if grep -q "^MaxAuthTries" "$SSHD_CONFIG"; then
  sudo sed -i 's/^MaxAuthTries.*/MaxAuthTries 3/' "$SSHD_CONFIG"
else
  echo "MaxAuthTries 3" | sudo tee -a "$SSHD_CONFIG" > /dev/null
fi
sudo systemctl restart sshd && log_info "Servicio SSH reiniciado con MaxAuthTries=3"

#Crear automaticamente los directorios skel personalizados si no existen
for grupo_skel in superadmin dbadmin webadmin useradmin moderadores; do
  SKEL_DIR="/etc/skel-$grupo_skel"
  if [ ! -d "$SKEL_DIR" ]; then
    if sudo mkdir -p "$SKEL_DIR" && sudo cp -r /etc/skel/. "$SKEL_DIR/"; then
      echo "Plantilla '$SKEL_DIR' creada y poblada desde /etc/skel - $(date)" | sudo tee -a "$LOG"
      echo "Bienvenido al rol $grupo_skel. Contacte a su administrador para instrucciones." | sudo tee "$SKEL_DIR/README.txt" > /dev/null
      log_info "Directorio skel para grupo $grupo_skel creado"
    else
      log_error "Error al crear skel para grupo $grupo_skel"
    fi
  fi
done

#FINAL DE LAS CONFIGURACIONES INCIALES AUTOAMTICAS

opc=0
while [[ "$opc" -ne 10 ]]; do
  clear
  echo "============================="
  echo "  Gestión de Usuarios Linux "
  echo "============================="
  echo "1) Alta de usuario"
  echo "2) Baja de usuario"
  echo "3) Modificar comentario"
  echo "4) Listado de usuarios"
  echo "5) Consulta de usuario"
  echo "6) Gestión de grupos"
  echo "7) Descativar usuario Root"
  echo "8) Bloquear usuario"
  echo "9) Desbloquear usuario"
  echo "10) Salir"
  echo "============================="
  read -p "Seleccione una opción: " opc
   
   case $opc in
    1)
    log_info "Crear usuario iniciado"
    echo "Crear usuario"
    echo "Recuerde que el nombre del usuario solo puede contener minúsculas, números y guiones."
    echo "El usuario tampoco puede iniciar con un número, ni se admiten espacios como separador."
usuario_valido=0
while [ "$usuario_valido" -eq 0 ]; do
    read -p "Ingrese nombre de usuario a crear: " us
  if [[ -z "$us" ]]; then
    echo "El nombre de usuario no puede estar vacío."
    log_error "Intento de creación con nombre vacío"
  elif [[ ! "$us" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
    echo "Nombre de usuario inválido. Solo puede contener minúsculas, números, '-' y '_'."
    log_error "Nombre de usuario inválido: $us"
  elif id "$us" &>/dev/null; then
    echo "El usuario ya existe."
    log_error "Intento de creación fallido: el usuario $us ya existe"
  else
    usuario_valido=1
  fi
done
#Mini menu para seleccionar skel
rol_valido=0
while [ "$rol_valido" -eq 0 ]; do
  echo "Seleccione el rol del nuevo usuario:"
  echo "1) Administrador de Base de Datos"
  echo "2) Administrador de PHP/Web"
  echo "3) Administrador de Usuarios"
  echo "4) Moderador"
  read -p "Opción: " rol

  case $rol in
    1) grupo="dbadmin"; rol_valido=1 ;;
    2) grupo="webadmin"; rol_valido=1 ;;
    3) grupo="useradmin"; rol_valido=1 ;;
    4) grupo="moderadores"; rol_valido=1 ;;
    *) echo "Rol inválido."; log_error "Rol inválido ingresado en creación de usuario" ;;
  esac
done

SKEL_DIR="/etc/skel-$grupo"

if ! getent group "$grupo" > /dev/null; then
  echo "El grupo '$grupo' no existe."
  log_error "Grupo $grupo no existe al intentar crear usuario $us"
elif [ ! -d "$SKEL_DIR" ]; then
  echo "Directorio skel '$SKEL_DIR' no encontrado."
  log_error "Directorio $SKEL_DIR no encontrado al crear usuario $us"
else
  sudo useradd -m -g "$grupo" -k "$SKEL_DIR" "$us"
  if [[ $? -eq 0 ]]; then
    echo "Alta: $us (rol: $grupo) - $(date)" | sudo tee -a "$LOG"
    log_info "Usuario $us creado con rol $grupo"
    echo "Ingrese la contraseña para el usuario: $us"
    sudo passwd "$us"
#Aplicar políticas de expiración e inactividad solo si no es superadmin
if [[ "$grupo" != "superadmin" ]]; then
    sudo chage -I 7 "$us"
    sudo chage -M 90 -m 3 -W 15 "$us"
    echo "Política de expiración aplicadas."
    echo "El usuario tiene un maximo de 90 dias para poder cambiar la contraseña."
    echo "Un minimo de 3 dias y 15 dias de llegando a los 90 se le avisara."
    echo "El usuario $us tendrá su contraseña expirada después de 7 días de inactividad."
    log_info "Política de expiración aplicada al usuario $us"
else
  echo "Usuario $us es superadmin: sin restricciones de expiración o inactividad de contraseña."
  log_info "Usuario $us es superadmin, sin políticas de expiración"
fi
 else
   echo "Error al crear el usuario."
   log_error "Fallo al ejecutar useradd para $us"
  fi
 fi

               ;;
    2)
    log_info "Eliminar usuario iniciado"
    echo "Eliminar usuario"
    read -p "Ingrese el nombre del usuario a eliminar: " us
    if [[ -z "$us" ]]; then
      echo "El nombre de usuario no puede estar vacío."
      log_error "Intento de eliminación con nombre vacío"
    elif [[ ! "$us" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
      echo "Nombre de usuario inválido."
      log_error "Nombre de usuario inválido en eliminación: $us"
    elif id "$us" &>/dev/null; then
      read -p "¿Desea eliminar también el directorio home? (s/n): " op
      if [[ "$op" == "s" ]]; then
        if sudo userdel -r "$us"; then
          log_info "Usuario $us eliminado con su directorio home"
        else
          log_error "Error al eliminar el usuario $us con directorio home"
        fi
      else
        if sudo userdel "$us"; then
          log_info "Usuario $us eliminado sin su directorio home"
        else
          log_error "Error al eliminar el usuario $us sin eliminar home"
        fi
      fi
      echo "Baja: $us - $(date)" | sudo tee -a $LOG
      echo "Usuario eliminado."
    else
      echo "El usuario no existe."
      log_error "El usuario $us no existe para eliminación"
    fi
           ;;
    
    
    3)
    log_info "Inicio de modificación de comentario"
    echo "Modificar comentario"
    read -p "Ingrese nombre de usuario: " us
    if [[ -z "$us" ]]; then
      echo "El nombre de usuario no puede estar vacío."
      log_error "Intento de modificación con nombre vacío"
    elif [[ ! "$us" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
      echo "Nombre de usuario inválido."
      log_error "Nombre de usuario inválido en modificación: $us"
    elif id "$us" &>/dev/null; then
      read -p "Ingrese nuevo comentario (nombre completo): " comen
      if [[ -z "$comen" ]]; then
        echo "El comentario no puede estar vacío."
        log_error "Comentario vacío ingresado para $us"
      else
        if sudo usermod -c "$comen" "$us"; then
          echo "Comentario modificado."
          log_info "Comentario modificado para el usuario $us"
        else
          echo "Error al modificar el comentario."
          log_error "Fallo al modificar comentario para el usuario $us"
        fi
      fi
    else
      echo "El usuario no existe."
      log_error "El usuario $us no existe para modificación de comentario"
    fi
            ;;
    
    4)
      echo "Usuarios existentes:"
      cut -d: -f1 /etc/passwd | sort
      ;;


    5)
    log_info "Consulta de información de usuario iniciada"
    read -p "Ingrese nombre de usuario: " us
    if [[ -z "$us" ]]; then
      echo "El nombre de usuario no puede estar vacío."
      log_error "Consulta fallida: nombre vacío"
    elif [[ ! "$us" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
      echo "Nombre de usuario inválido."
      log_error "Consulta fallida: nombre inválido $us"
    elif id "$us" &>/dev/null; then
      id "$us"
      log_info "Consulta exitosa para usuario $us"
    else
      echo "El usuario no existe."
      log_error "Consulta fallida: el usuario $us no existe"
    fi
      ;;

    6)
    log_info "Gestión de grupos iniciada"
    echo "---- Gestión de Grupos ----"
    echo "a) Crear grupo"
    echo "b) Eliminar grupo"
    echo "c) Listar grupos"
    read -p "Seleccione una opción: " gopc

    if [[ -z "$gopc" ]]; then
      echo "Debe ingresar una opción."
      log_error "Gestión de grupos fallida: opción vacía"
    else
      case $gopc in
        a)
          read -p "Nombre del grupo a crear: " gname
          if [[ -z "$gname" ]]; then
            echo "El nombre del grupo no puede estar vacío."
            log_error "Creación de grupo fallida: nombre vacío"
          elif getent group "$gname" > /dev/null; then
            echo "El grupo ya existe."
            log_error "Creación de grupo fallida: grupo $gname ya existe"
          else
            if sudo groupadd "$gname"; then
              echo "Grupo $gname creado - $(date)" | sudo tee -a $LOG
              log_info "Grupo $gname creado exitosamente"
            else
              log_error "Fallo al crear el grupo $gname"
            fi
          fi
          ;;
        b)
          read -p "Nombre del grupo a eliminar: " gname
          if [[ -z "$gname" ]]; then
            echo "El nombre del grupo no puede estar vacío."
            log_error "Eliminación de grupo fallida: nombre vacío"
          elif getent group "$gname" > /dev/null; then
            if sudo groupdel "$gname"; then
              echo "Grupo $gname eliminado - $(date)" | sudo tee -a $LOG
              log_info "Grupo $gname eliminado exitosamente"
            else
              log_error "Fallo al eliminar el grupo $gname"
            fi
          else
            echo "El grupo no existe."
            log_error "Eliminación de grupo fallida: grupo $gname no existe"
          fi
          ;;
        c)
          echo "Grupos existentes: "
          cut -d: -f1 /etc/group | sort
          log_info "Listado de grupos existente mostrado"
          ;;
        *)
          echo "Opción inválida."
          log_error "Opción inválida seleccionada en gestión de grupos"
          ;;
      esac
    fi
      ;;

    7)
    log_info "Desactivación del usuario root iniciada"
    shell_root=$(grep "^root:" /etc/passwd | cut -d: -f7)
    if [[ "$shell_root" == "/usr/sbin/nologin" || "$shell_root" == "/bin/false" ]]; then
      echo "El usuario root ya tiene login deshabilitado."
      log_info "El login de root ya estaba deshabilitado"
    else
      linea_root=$(grep "^root:" /etc/passwd)
      campos_previos=$(echo "$linea_root" | cut -d: -f1-6 | paste -sd: -)
      nueva_linea="$campos_previos:/usr/sbin/nologin"
      if sudo sed -i "s#^root:.*#$nueva_linea#" /etc/passwd; then
        echo "Login de root deshabilitado - $(date)" | sudo tee -a "$LOG"
        log_info "Login de root deshabilitado"
      else
        echo "No se pudo deshabilitar login de root." | sudo tee -a "$LOG"
        log_error "Fallo al deshabilitar login de root"
      fi
    fi
      ;;

    8)
    log_info "Inicio del bloqueo de usuario"
    echo "Bloquear usuario"
    read -p "Ingrese nombre de usuario a bloquear: " us
    if [[ -z "$us" ]]; then
      echo "El nombre de usuario no puede estar vacío."
      log_error "Bloqueo fallido: nombre vacío"
    elif [[ ! "$us" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
      echo "Nombre de usuario inválido."
      log_error "Bloqueo fallido: nombre inválido $us"
    elif getent passwd "$us" > /dev/null; then
      if sudo usermod -L "$us"; then
        echo "Usuario $us bloqueado exitosamente."
        echo "Bloqueo: $us - $(date)" | sudo tee -a "$LOG"
        log_info "Usuario $us bloqueado"
      else
        echo "No se pudo bloquear al usuario $us. Puede que ya esté bloqueado."
        log_error "Fallo al bloquear usuario $us"
      fi
    else
      echo "El usuario no existe."
      log_error "Bloqueo fallido: el usuario $us no existe"
    fi
      ;;

    9)
    log_info "Inicio del desbloqueo de usuario"
    echo "Desbloquear usuario"
    read -p "Ingrese nombre de usuario a desbloquear: " us
    if [[ -z "$us" ]]; then
      echo "El nombre de usuario no puede estar vacío."
      log_error "Desbloqueo fallido: nombre vacío"
    elif [[ ! "$us" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
      echo "Nombre de usuario inválido."
      log_error "Desbloqueo fallido: nombre inválido $us"
    elif getent passwd "$us" > /dev/null; then
      if sudo usermod -U "$us"; then
        echo "Usuario $us desbloqueado exitosamente."
        echo "Desbloqueo: $us - $(date)" | sudo tee -a "$LOG"
        log_info "Usuario $us desbloqueado"
      else
        echo "No se pudo desbloquear al usuario $us. Puede que no esté bloqueado."
        log_error "Fallo al desbloquear usuario $us"
      fi
    else
      echo "El usuario no existe."
      log_error "Desbloqueo fallido: el usuario $us no existe"
    fi
      ;;

    10)
      log_info "Saliendo del sistema por solicitud del usuario"
      echo "Saliendo..."
      ;;

    *)
      echo "Opción inválida."
      log_error "Opción inválida seleccionada en menú principal"
      ;;

  esac
 
   echo ""
   read -p "Presione Enter para continuar..."
   done
    
    
    
    
    
    
    
    
    
    
    
